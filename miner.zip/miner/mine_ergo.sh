#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=us.ergo.herominers.com:10250
WALLET=9iBQygF3jotYsT1JogiGvfdC7Ve8pLrPuqyqX5KR6kudFMn4eSs.lolsaja

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./lolMiner --algo AUTOLYKOS2 --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./lolMiner --algo AUTOLYKOS2 --pool $POOL --user $WALLET $@
done
